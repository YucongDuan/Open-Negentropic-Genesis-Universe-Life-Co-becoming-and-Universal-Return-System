from pathlib import Path
import sys,json,tempfile
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/"src"))
from yuandao86.dataio import *
from yuandao86.evaluator import evaluate
from yuandao86.explorer import explore
from yuandao86.native import encode,decode
from yuandao86.memory import remember,verify,pulse,reopen
from yuandao86.conformance import selftest
T=[]
def c(n,x):T.append((n,bool(x)))
c("counts",len(operators())==8 and len(laws())==5 and len(closures())==10 and len(gates())==10 and len(roots())==10 and len(questions())==12)
good=json.loads((root/"examples/open_genesis.json").read_text(encoding="utf-8"));bad=json.loads((root/"examples/extractive_order.json").read_text(encoding="utf-8"));z=json.loads((root/"examples/zombie_order.json").read_text(encoding="utf-8"))
c("states",evaluate(good)["state"]=="OPEN_NEGENTROPIC_GENESIS" and evaluate(bad)["state"]=="EXTRACTIVE_ORDER" and evaluate(z)["state"]=="ZOMBIE_ORDER")
r=explore("什么是真正的熵减与宇宙生命融合？");c("chosen",r["chosen"]["id"]=="H3_OPEN_NEGENTROPIC_RETURN")
n=encode(r);d=decode(n);c("native",d["digest"]==r["exploration_digest"] and len(d["operators"])==8)
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/"l.jsonl";remember(r,p);c("ledger",verify(p)["valid"] and pulse(p)["source_case"]==r["compiled"]["case_id"]);r2=reopen(r,"出现新的外部化能耗证据");c("reopen",r2["revision"]["status"]=="REOPENED" and r2["revision"]["previous_digest"]==r["exploration_digest"])
c("selftest",selftest()["passed"])
for n,v in T:print(("PASS" if v else "FAIL"),n)
print(sum(v for _,v in T),"passed,",sum(not v for _,v in T),"failed")
raise SystemExit(0 if all(v for _,v in T) else 1)

from __future__ import annotations
import re
from .dataio import roots,closures,operators
from .util import digest,slug
KEY={
"R1_DIFFERENCE_COLLAPSE":["相同","不同","分类","身份","平均","difference","identity","category"],
"R2_CONTINUITY_BREAK":["记忆","来源","历史","连续","死亡","memory","source","continuity","death"],
"R3_FALSE_CLOSURE":["终极","完整","本质","全部","final","complete","essence","all"],
"R4_TRANSFORMATION_BLOCK":["如何","解决","实现","行动","how","solve","implement","action"],
"R5_CONSEQUENCE_DISCONNECT":["后果","反馈","责任","返还","consequence","feedback","responsibility","return"],
"R6_VALUE_CAPTURE":["价值","善","恶","正义","目标","value","good","evil","justice","purpose"],
"R7_HORIZON_CLOSURE":["未来","永远","开放","自由","future","forever","open","freedom"],
"R8_ENTROPY_EXTERNALIZATION":["熵","能量","生态","资源","entropy","energy","ecology","resource"],
"R9_MEMORY_FAILURE":["存储","遗忘","重构","人格","storage","forget","reconstruct","persona"],
"R10_REFLEXIVE_CAPTURE":["规则","评价","观察者","系统","rule","evaluate","observer","system"],}
ROOT={x["id"]:x for x in roots()}; CLOSE=closures()
def compile_problem(question,context="",purpose="locate the root and reopen the future"):
 text=(question+" "+context+" "+purpose).lower(); hits=[]
 for rid,words in KEY.items():
  sig=[w for w in words if w.lower() in text]
  if sig: hits.append({"root_id":rid,"name_cn":ROOT[rid]["name_cn"],"signals":sig,"question_cn":ROOT[rid]["question_cn"]})
 if not hits: hits=[{"root_id":"R3_FALSE_CLOSURE","name_cn":ROOT["R3_FALSE_CLOSURE"]["name_cn"],"signals":["generic closure risk"],"question_cn":ROOT["R3_FALSE_CLOSURE"]["question_cn"]},{"root_id":"R4_TRANSFORMATION_BLOCK","name_cn":ROOT["R4_TRANSFORMATION_BLOCK"]["name_cn"],"signals":["problem asks for transition"],"question_cn":ROOT["R4_TRANSFORMATION_BLOCK"]["question_cn"]}]
 c_hits=[]
 for c in CLOSE:
  if any(k in c["id"] for k in ["CONCEPTUAL","IDENTITY","VALUE","MEMORY","CONSEQUENCE","POWER","PURPOSE","RESOURCE","TEMPORAL","COSMIC"]):
   # explicit, inspectable heuristic mapping rather than hidden model score
   related={"FC_CONCEPTUAL":"R1_DIFFERENCE_COLLAPSE","FC_IDENTITY":"R1_DIFFERENCE_COLLAPSE","FC_VALUE":"R6_VALUE_CAPTURE","FC_MEMORY":"R9_MEMORY_FAILURE","FC_CONSEQUENCE":"R5_CONSEQUENCE_DISCONNECT","FC_POWER":"R6_VALUE_CAPTURE","FC_PURPOSE":"R6_VALUE_CAPTURE","FC_RESOURCE":"R8_ENTROPY_EXTERNALIZATION","FC_TEMPORAL":"R2_CONTINUITY_BREAK","FC_COSMIC":"R3_FALSE_CLOSURE"}[c["id"]]
   if any(h["root_id"]==related for h in hits): c_hits.append(c)
 out={"case_id":"YD86-"+slug(question),"question":question,"context":context,"purpose":purpose,"deconceptualized_handles":[{"id":"x0","role":"question-bearing trajectory"},{"id":"x1","role":"current occurrence field"},{"id":"x2","role":"sought or avoided future"},{"id":"x3","role":"affected and excluded trajectories"}],"operators":[x["id"] for x in operators()],"root_hits":hits,"false_closure_hits":c_hits,"terminal_remainder":"Any current answer must disclose what it excludes and how it can be reopened."}
 out["compile_digest"]=digest(out); return out

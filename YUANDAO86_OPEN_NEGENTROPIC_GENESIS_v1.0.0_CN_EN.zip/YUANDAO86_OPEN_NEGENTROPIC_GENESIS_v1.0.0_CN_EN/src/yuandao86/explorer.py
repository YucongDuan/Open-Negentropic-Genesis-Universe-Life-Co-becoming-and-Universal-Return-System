from __future__ import annotations
from .compiler import compile_problem
from .dataio import gates,operators,laws
from .util import digest
def _vector(status): return "".join("1" if x else "0" for x in status)
def explore(question,context="",purpose="locate the root and reopen the future"):
 comp=compile_problem(question,context,purpose)
 rootnames=[x["name_cn"] for x in comp["root_hits"]]
 hypotheses=[
 {"id":"H1_CONCEPT_PATCH","name_cn":"概念修补","thesis_cn":"在既有对象与规则中重新命名、分类或优化。","gates":[True,False,False,True,False,False,False,False,False,False]},
 {"id":"H2_LOCAL_ORDER","name_cn":"局部秩序优化","thesis_cn":"提高局部预测、效率和控制，但保持现有边界。","gates":[True,False,True,True,False,False,False,False,False,False]},
 {"id":"H3_OPEN_NEGENTROPIC_RETURN","name_cn":"开放负熵回返","thesis_cn":"恢复余量与后果，重构记忆，公开熵外排，并以可逆现实行动重新打开当前整体。","gates":[True,True,True,True,True,True,True,True,True,True]},]
 ranked=sorted(hypotheses,key=lambda h:(h["gates"].count(False),h["id"])); chosen=ranked[0]
 next_action="Build one minimal reversible real-world probe that can distinguish the competing hypotheses; record energy/cost, affected trajectories, consequence return, and terminal remainder."
 out={"system":"YUANDAO86","version":"1.0.0","compiled":comp,"root_summary":"、".join(rootnames),"hypotheses":ranked,"chosen":chosen,"chosen_vector":_vector(chosen["gates"]),"root_laws":laws(),"next_action":next_action,"candidate_tao":"开放负熵回返：局部秩序只有在余量、熵输出和后果返回并改变下一轮时，才不是把问题外排。","terminal_value":"共自成：成为自身，也让其他轨迹仍能成为。","physical_boundary":"Local entropy reduction requires energy throughput and may export entropy; the system therefore evaluates boundary lifting instead of claiming universal physical entropy decrease.","phenomenal_claim":"OPEN_NOT_CERTIFIED"}
 out["dikwp_projection"]={"D":{"content":"可跨变化恢复的来源、承诺和记忆谱系","from":["M_RETENTION","R_RETURN"]},"I":{"content":"新差异、异常、受影响者和终极余量","from":["D_DISTINCTION","O_REMAINDER"]},"K":{"content":"当前阶段的约束整体，明确范围和可重开条件","from":["C_CONSTRAINT"]},"W":{"content":"开放负熵回返与共自成的方向选择","from":["V_VIABLE_POTENTIAL"]},"P":{"content":"进入现实、接受回果并触发下一轮的可逆行动","from":["A_ACTUALIZATION","R_RETURN"]},"unmapped_remainder":"E/O/R are not reduced without remainder; occurrence, remainder and return remain cross-positional conditions."}
 out["exploration_digest"]=digest(out); return out

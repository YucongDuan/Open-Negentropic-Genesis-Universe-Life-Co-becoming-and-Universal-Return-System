from __future__ import annotations
from .dataio import gates, states
from .util import digest
GATES=gates(); STATE={x["id"]:x for x in states()}
def evaluate(case):
 m=case.get("measurements",{})
 bits=[1 if m.get(g["field"]) is True else 0 for g in GATES]
 vector="".join(map(str,bits)); missing=[g for g,b in zip(GATES,bits) if not b]
 if all(bits): state="OPEN_NEGENTROPIC_GENESIS"
 elif m.get("repair_reciprocity") and m.get("consequence_return") and m.get("closure_reopenable"): state="REPAIRING_RETURN"
 elif m.get("productive_constraint") and not m.get("externalized_entropy_accounted") and not m.get("repair_reciprocity"): state="EXTRACTIVE_ORDER"
 elif m.get("productive_constraint") and not m.get("reconstructive_memory") and not m.get("future_options_expanded") and not m.get("closure_reopenable"): state="ZOMBIE_ORDER"
 elif not m.get("consequence_return") and m.get("productive_constraint"): state="FALSE_CLOSURE"
 elif sum(bits)<=2: state="ENTROPIC_DISPERSAL"
 elif m.get("productive_constraint") and m.get("source_traceable"): state="STATIC_ORDER"
 else: state="OPEN_REMAINDER"
 physical=case.get("physical",{})
 if physical.get("measurement_state")!="MEASURED": physical={"measurement_state":physical.get("measurement_state","UNMEASURED"),"joules":None,"note":"No physical-energy claim is made without telemetry."}
 out={"system":"YUANDAO86","version":"1.0.0","case_id":case.get("case_id"),"description":case.get("description"),"negentropy_vector":vector,"state":state,"state_cn":STATE[state]["name_cn"],"open_gates":[{"id":g["id"],"name_cn":g["name_cn"],"question_cn":g["question_cn"]} for g in missing],"physical":physical,"claim_boundary":"This is a structural open-negentropy assessment, not a physical-law proof, legal judgment, moral essence label, or consciousness certification."}
 out["evaluation_digest"]=digest(out); return out

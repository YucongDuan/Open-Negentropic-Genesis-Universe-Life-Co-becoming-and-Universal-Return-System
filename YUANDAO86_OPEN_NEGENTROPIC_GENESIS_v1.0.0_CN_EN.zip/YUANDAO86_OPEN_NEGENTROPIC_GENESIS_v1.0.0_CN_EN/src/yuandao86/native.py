from __future__ import annotations
import json
HEADER="YD86|1"
def encode(run):
 lines=[HEADER]
 comp=run["compiled"]
 for op in comp["operators"]:lines.append("O|"+op)
 for r in comp["root_hits"]:lines.append("R|"+r["root_id"]+"|"+",".join(r.get("signals",[])))
 lines.append("H|"+run["chosen"]["id"]+"|"+run["chosen_vector"]);lines.append("X|"+run["exploration_digest"]);return "\n".join(lines)+"\n"
def decode(text):
 lines=[x.strip() for x in text.splitlines() if x.strip()]
 if not lines or lines[0]!=HEADER:raise ValueError("bad YD86 header")
 out={"header":HEADER,"operators":[],"roots":[],"chosen":None,"digest":None}
 for line in lines[1:]:
  p=line.split("|");
  if p[0]=="O":out["operators"].append(p[1])
  elif p[0]=="R":out["roots"].append({"root_id":p[1],"signals":p[2].split(",") if len(p)>2 and p[2] else []})
  elif p[0]=="H":out["chosen"]={"id":p[1],"vector":p[2]}
  elif p[0]=="X":out["digest"]=p[1]
 return out

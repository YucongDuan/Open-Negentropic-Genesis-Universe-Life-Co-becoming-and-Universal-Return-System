from __future__ import annotations
from .dataio import operators,laws,closures,gates,states,roots,questions
from .evaluator import evaluate
from .explorer import explore
from .native import encode,decode
def selftest():
 checks=[]
 def c(name,ok):checks.append({"name":name,"passed":bool(ok)})
 c("operators_8",len(operators())==8);c("laws_5",len(laws())==5);c("closures_10",len(closures())==10);c("gates_10",len(gates())==10);c("states_8",len(states())==8);c("roots_10",len(roots())==10);c("questions_12",len(questions())==12)
 good={"case_id":"g","description":"g","measurements":{g["field"]:True for g in gates()},"physical":{"measurement_state":"UNMEASURED","joules":None}}
 bad={"case_id":"b","description":"b","measurements":{g["field"]:False for g in gates()},"physical":{"measurement_state":"UNMEASURED","joules":None}}
 c("open_state",evaluate(good)["state"]=="OPEN_NEGENTROPIC_GENESIS");c("dispersal_state",evaluate(bad)["state"]=="ENTROPIC_DISPERSAL")
 run=explore("什么是真正的熵减与宇宙生命融合？");nat=encode(run);dec=decode(nat)
 c("explore",run["chosen"]["id"]=="H3_OPEN_NEGENTROPIC_RETURN");c("native_roundtrip",dec["digest"]==run["exploration_digest"] and len(dec["operators"])==8)
 return {"system":"YUANDAO86","version":"1.0.0","passed":all(x["passed"] for x in checks),"count":len(checks),"checks":checks,"reference_digest":run["exploration_digest"]}

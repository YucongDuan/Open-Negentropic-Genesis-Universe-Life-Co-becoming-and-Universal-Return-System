from __future__ import annotations
import json,hashlib,re
def canonical_bytes(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")
def digest(x): return hashlib.sha256(canonical_bytes(x)).hexdigest()
def slug(s):
 s=re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+","-",s.strip()).strip("-")
 return s[:48] or "case"

from __future__ import annotations
import argparse,json
from pathlib import Path
from .dataio import *
from .evaluator import evaluate
from .explorer import explore
from .memory import remember,reopen,pulse,verify
from .native import encode,decode
from .conformance import selftest
def emit(x):print(json.dumps(x,ensure_ascii=False,indent=2))
def main(argv=None):
 p=argparse.ArgumentParser(prog="yuandao86");s=p.add_subparsers(dest="cmd",required=True)
 for n in ["summary","operators","laws","closures","gates","questions","selftest"]:s.add_parser(n)
 x=s.add_parser("assess");x.add_argument("case")
 x=s.add_parser("explore");x.add_argument("question");x.add_argument("--context",default="");x.add_argument("--purpose",default="locate the root and reopen the future");x.add_argument("--out")
 x=s.add_parser("native");x.add_argument("run");x.add_argument("--out")
 x=s.add_parser("decode");x.add_argument("file")
 x=s.add_parser("remember");x.add_argument("run");x.add_argument("--ledger",required=True)
 x=s.add_parser("verify-ledger");x.add_argument("ledger")
 x=s.add_parser("reopen");x.add_argument("run");x.add_argument("evidence");x.add_argument("--out")
 x=s.add_parser("pulse");x.add_argument("ledger")
 a=p.parse_args(argv)
 if a.cmd=="summary":emit({"system":"YUANDAO86","version":"1.0.0","mode":"MESH86_YUANDAO_OPEN_NEGENTROPIC_GENESIS","operators":len(operators()),"root_laws":len(laws()),"false_closures":len(closures()),"negentropy_gates":len(gates()),"problem_roots":len(roots()),"ultimate_questions":len(questions()),"candidate_tao":"开放负熵回返","terminal_value":"共自成"})
 elif a.cmd=="operators":emit(operators())
 elif a.cmd=="laws":emit(laws())
 elif a.cmd=="closures":emit(closures())
 elif a.cmd=="gates":emit(gates())
 elif a.cmd=="questions":emit(questions())
 elif a.cmd=="assess":emit(evaluate(json.loads(Path(a.case).read_text(encoding="utf-8"))))
 elif a.cmd=="explore":
  r=explore(a.question,a.context,a.purpose);
  if a.out:Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
  emit(r)
 elif a.cmd=="native":
  t=encode(json.loads(Path(a.run).read_text(encoding="utf-8")));
  if a.out:Path(a.out).write_text(t,encoding="utf-8")
  else:print(t,end="")
 elif a.cmd=="decode":emit(decode(Path(a.file).read_text(encoding="utf-8")))
 elif a.cmd=="remember":emit(remember(json.loads(Path(a.run).read_text(encoding="utf-8")),a.ledger))
 elif a.cmd=="verify-ledger":emit(verify(a.ledger))
 elif a.cmd=="reopen":
  r=reopen(json.loads(Path(a.run).read_text(encoding="utf-8")),a.evidence);
  if a.out:Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
  emit(r)
 elif a.cmd=="pulse":emit(pulse(a.ledger))
 elif a.cmd=="selftest":
  r=selftest();emit(r);return 0 if r["passed"] else 1
 return 0

from __future__ import annotations
import json
from importlib.resources import files
def load(name): return json.loads(files("yuandao86").joinpath("data",name).read_text(encoding="utf-8"))
def operators(): return load("operators.json")
def laws(): return load("root_laws.json")
def closures(): return load("false_closures.json")
def gates(): return load("negentropy_gates.json")
def states(): return load("states.json")
def roots(): return load("problem_roots.json")
def questions(): return load("ultimate_questions.json")

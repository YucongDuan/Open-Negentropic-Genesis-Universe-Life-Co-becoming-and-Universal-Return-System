from __future__ import annotations
import json,hashlib
from pathlib import Path
from datetime import datetime,timezone
from .util import canonical_bytes,digest
from .explorer import explore
def append(path,event):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);prev="0"*64
 if p.exists():
  lines=[x for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
  if lines: prev=json.loads(lines[-1])["hash"]
 body={"timestamp":datetime.now(timezone.utc).isoformat(),"previous":prev,"event":event};body["hash"]=hashlib.sha256(prev.encode()+canonical_bytes(event)+body["timestamp"].encode()).hexdigest()
 with p.open("a",encoding="utf-8") as f:f.write(json.dumps(body,ensure_ascii=False)+"\n")
 return body
def verify(path):
 p=Path(path);prev="0"*64;errs=[];count=0
 if not p.exists():return {"valid":False,"count":0,"errors":["missing"]}
 for i,line in enumerate(p.read_text(encoding="utf-8").splitlines(),1):
  if not line.strip():continue
  x=json.loads(line);exp=hashlib.sha256(prev.encode()+canonical_bytes(x["event"])+x["timestamp"].encode()).hexdigest()
  if x.get("previous")!=prev or x.get("hash")!=exp:errs.append(i)
  prev=x.get("hash",prev);count+=1
 return {"valid":not errs,"count":count,"head":prev,"errors":errs}
def remember(run,ledger):
 event={"type":"EXPLORATION_RECONSOLIDATED","case_id":run["compiled"]["case_id"],"question":run["compiled"]["question"],"chosen":run["chosen"]["id"],"root_hits":[x["root_id"] for x in run["compiled"]["root_hits"]],"terminal_remainder":run["compiled"]["terminal_remainder"],"next_action":run["next_action"],"digest":run["exploration_digest"]}
 rec=append(ledger,event);return {"record":rec,"ledger":verify(ledger)}
def reopen(previous,new_evidence):
 q=previous["compiled"]["question"];ctx=previous["compiled"].get("context","")+"\nNEW EVIDENCE: "+new_evidence
 new=explore(q,ctx,previous["compiled"].get("purpose","locate the root and reopen the future"));new["revision"]={"status":"REOPENED","previous_digest":previous.get("exploration_digest"),"new_evidence":new_evidence,"preserved_remainder":previous["compiled"].get("terminal_remainder")};new["exploration_digest"]=digest(new);return new
def pulse(ledger):
 p=Path(ledger)
 if not p.exists():return {"purpose":"Create the first traceable problem exploration and preserve its remainder.","source":"EMPTY_LEDGER"}
 events=[json.loads(x)["event"] for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
 unresolved=[e for e in events if e.get("terminal_remainder") or e.get("next_action")]
 if not unresolved:return {"purpose":"Search for a new difference that current closures cannot explain.","source":"NO_OPEN_REMAINDER"}
 e=unresolved[-1];return {"purpose":e.get("next_action") or "Reopen the latest unresolved remainder.","source_case":e.get("case_id"),"source_digest":e.get("digest")}

# YUANDAO86｜元道86

开放负熵发生、宇宙生命融合与万题回返终极系统。

## 核心候选

- 万题之根：局部闭合把自己误认成整体。
- 候选天道：开放负熵回返。
- 终极价值：共自成。
- 物理边界：局部熵减需要能量通量并可能向外排熵；系统不宣称宇宙总熵下降。

## 快速运行

```bash
python dist/YUANDAO86.pyz summary
python dist/YUANDAO86.pyz explore "什么是真正的熵减与宇宙生命融合？" --out run.json
python dist/YUANDAO86.pyz assess examples/open_genesis.json
python dist/YUANDAO86.pyz native run.json --out run.yd86
python dist/YUANDAO86.pyz remember run.json --ledger living_ledger.jsonl
python dist/YUANDAO86.pyz pulse living_ledger.jsonl
python dist/YUANDAO86.pyz selftest
```

直接打开 `site/index.html` 使用离线系统。
